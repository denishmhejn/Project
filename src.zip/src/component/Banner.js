import React from 'react'
import "../css/Banner.css";

export default function Banner() {
  return (
    <>
     <div className="bannerbody">
        <div className="quiz-banner">
      <span className="banner-text">
        Ready to test your knowledge? Take our quiz now and challenge yourself!
      </span>
      <button className="banner-button">QUIZZPRO</button><br/>
      </div>
    
    </div>
    {/* <div className="ad-mid-column">
    <div className="ad-banner-mid">Ad Display Banners</div>
    <div className="ad-banner-mid">Ad Display Banners</div>
    <div className="ad-banner-mid">Ad Display Banners</div>
    </div> */}

    
    
    </>
   
    
    
  )
}
